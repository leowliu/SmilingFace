//
//  SmilingFaceAppDelegate.h
//  SmilingFace
//
//  Created by Benny on 6/29/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
@class View;

@interface SmilingFaceAppDelegate : NSObject <UIApplicationDelegate> {
    View *view;
    UIWindow *_window;
}

//@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
