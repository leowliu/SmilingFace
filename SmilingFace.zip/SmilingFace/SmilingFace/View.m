//
//  View.m
//  SmilingFace
//
//  Created by Benny on 6/29/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "View.h"


@implementation View

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.backgroundColor = [UIColor whiteColor];
    }
    return self;
}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
    CGRect b = self.bounds;
    CGFloat radius = .3 * b.size.width;
    
    CGRect r = CGRectMake(b.origin.x + b.size.width / 2 - radius, 
                          b.origin.y + b.size.height /2 - radius, 
                          2 * radius, 
                          2 * radius);
    
    CGContextRef c = UIGraphicsGetCurrentContext();
    CGContextBeginPath(c);
    CGContextAddEllipseInRect(c, r);
    CGContextSetRGBFillColor(c, 1.0, 1.0, 0.0, 0.5); /* yellow */
    CGContextFillPath(c);
    
    CGRect r1 = CGRectMake(120, 
                           200, 
                           20, 
                           20);
    
    CGContextBeginPath(c);
    CGContextAddEllipseInRect(c, r1);
    CGContextSetRGBFillColor(c, 0.0, 0.0, 0.0, 1.0); /* black */
    CGContextFillPath(c);
    
    CGRect r2 = CGRectMake(180, 
                           200, 
                           20, 
                           20);
    
    CGContextBeginPath(c);
    CGContextAddEllipseInRect(c, r2);
    CGContextSetRGBFillColor(c, 0.0, 0.0, 0.0, 1.0); /* black */
    CGContextFillPath(c);
    
    CGContextBeginPath(c);
    CGContextMoveToPoint(c,135.0,270.0);
    CGContextAddArcToPoint(c, 160.0, 280.0, 220.0, 250.0, 80.0);
    CGFloat zStrokeColour3[]    = {0.0,0.0,0.0,1.0};
    CGContextSetStrokeColor(c,zStrokeColour3);
    CGContextSetLineWidth(c,3.0);
    CGContextDrawPath(c,kCGPathStroke);
    
    
    NSLog(@"Frame: %f, %f, %f, %f", self.frame.origin.x, self.frame.origin.y, self.frame.size.width, self.frame.size.height);
    NSLog(@"Bounds: %f, %f, %f, %f", self.bounds.origin.x, self.bounds.origin.y, self.bounds.size.width, self.bounds.size.height);
}


- (void)dealloc
{
    [super dealloc];
}

@end
