//
//  View.h
//  SmilingFace
//
//  Created by Benny on 6/29/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface View : UIView {
    
}

@end
