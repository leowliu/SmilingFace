//
//  SmilingFaceTests.h
//  SmilingFaceTests
//
//  Created by Benny on 6/29/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface SmilingFaceTests : SenTestCase {
@private
    
}

@end
